# DO NOT TRY TO COMMIT YOUR DATASET INTO GIT

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑

This folder is for your (presumably very large) datasets, use a [downloader](../downloaders/) instead of trying to use git to manage your dataset.
