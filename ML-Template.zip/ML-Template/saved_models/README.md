a place for saved model files. be careful checking in large models to git, and consider using git LFS when appropriate.
