#!/bin/bash

sudo docker build -t pytorch-jupyter-openai .
