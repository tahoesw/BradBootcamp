# Downloaders

make sure you download your data to the ```/data``` folder and either do not check it into github or use [github LFS](https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-git-large-file-storage)
